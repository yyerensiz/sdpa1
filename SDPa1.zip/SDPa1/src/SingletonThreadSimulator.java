import java.util.concurrent.ExecutorService;
import java.util.concurrent.ExecutionException;

import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Callable;

import java.util.ArrayList;

import java.util.List;

//to run Singleton with Threads
public class SingletonThreadSimulator {
    public static void main(String[] args) {
        int numberOfThreads = 5;

        ExecutorService executorService = Executors.newFixedThreadPool(numberOfThreads);

        List<Future<Singleton>> futures = new ArrayList<>();

        for (int i = 0; i < numberOfThreads; i++) {
            Callable<Singleton> task = Singleton::getInstance;
            Future<Singleton> future = executorService.submit(task);
            futures.add(future);
        }

        executorService.shutdown();

        for (Future<Singleton> future : futures) {
            try {
                Singleton singleton = future.get();
                singleton.demonstrateFunctionality();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }
    }
}