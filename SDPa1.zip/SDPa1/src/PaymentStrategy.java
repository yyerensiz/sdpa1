//interface to Payment methods
public interface PaymentStrategy {
    void processPayment(double amount);
}
