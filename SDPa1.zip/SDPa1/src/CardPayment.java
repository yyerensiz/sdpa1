public class CardPayment implements PaymentStrategy {
    private String cardNumber;
    private String cardHolderName;
    private String expiryDate;

    public CardPayment(String cardNumber, String cardHolderName, String expiryDate) {
        this.cardNumber = cardNumber;
        this.cardHolderName = cardHolderName;
        this.expiryDate = expiryDate;
    }

    @Override
    public void processPayment(double amount) {
        System.out.println("Processing Card Payment of tg" + amount + " using Card Number: " + cardNumber +
                ", Card Holder: " + cardHolderName + ", Expiry Date: " + expiryDate);
    }
}