public class QrPayment implements PaymentStrategy {
    private String qrCode;

    public QrPayment(String qrCode) {
        this.qrCode = qrCode;
    }

    @Override
    public void processPayment(double amount) {
        System.out.println("Processing QR Payment of tg" + amount + " using QR Code: " + qrCode);
    }
}