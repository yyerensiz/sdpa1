import java.util.Scanner;
//to run Strategy pattern and shop
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ShoppingCart cart = new ShoppingCart();

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Add Product to Cart");
            System.out.println("2. View Cart");
            System.out.println("3. Pay off");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter product name: ");
                    String name = scanner.next();
                    System.out.print("Enter product price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Enter product quantity: ");
                    int quantity = scanner.nextInt();
                    Product product = new Product(name, price, quantity);
                    cart.addProduct(product);
                    System.out.println("Product added to the cart.");
                    break;
                case 2:
                    cart.displayCart();
                    break;
                case 3:
                    System.out.println("Select payment method:");
                    System.out.println("1. QR Payment");
                    System.out.println("2. Card Payment");
                    //System.out.println("3. Cash Payment");
                    int paymentChoice = scanner.nextInt();
                    PaymentStrategy paymentStrategy = null;

                    if (paymentChoice == 1) {
                        System.out.print("Enter QR Code: ");
                        String qrCode = scanner.next();
                        paymentStrategy = new QrPayment(qrCode);
                    } else if (paymentChoice == 2) {
                        System.out.print("Enter Card Number: ");
                        String cardNumber = scanner.next();
                        System.out.print("Enter Card Holder Name: ");
                        String cardHolderName = scanner.next();
                        System.out.print("Enter Expiry Date: ");
                        String expiryDate = scanner.next();
                        paymentStrategy = new CardPayment(cardNumber, cardHolderName, expiryDate);
                    }
                    else if (paymentChoice == 3) {
                        //paymentStrategy = new CashPayment();
                    }

                    if (paymentStrategy != null) {
                        cart.checkout(paymentStrategy);
                        System.out.println("Thank you for your purchase!");
                        System.exit(0);
                    } else {
                        System.out.println("Invalid payment method selected.");
                    }
                    break;
                case 4:
                    System.out.println("Exiting the program. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
